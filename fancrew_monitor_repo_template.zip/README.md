# Fancrew Monitor Notifier

このリポジトリは、[ファンくる](https://www.fancrew.jp/search/result/4) の新着モニターを定期的にチェックし、Pushover で通知します。

## 構成

- `.github/workflows/monitor.yml` : GitHub Actions スケジューラ
- `check_monitor.py` : 本体スクリプト
- `requirements.txt` : 依存ライブラリ

## 実行方法

1. リポジトリにファイルをアップロード
2. `Actions` タブを開いて手動実行、または自動実行を待つ